import {atom} from "recoil"

export const dayState = atom({
  key : 'dayState',
  default : 'Day'
})


